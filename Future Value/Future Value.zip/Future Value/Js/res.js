document.write("Investment amount = " + investment);
document.write(" Interest rate = " + rate);
document.write(" Years = " + years);
document.write(" Future Value is " + futureValue + "<br>");
